function setup() {
    createCanvas(windowWidth, windowHeight);
    background(255);

    let heatmap = new HeatMap([[3,2,1], [1, 2, 3]], "rainbow", 2, 1);
    heatmap.display(0, 0, 500);
}